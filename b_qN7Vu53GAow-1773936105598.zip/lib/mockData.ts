import { Route, PatientAccess } from "@/context/AppContext"

// Mock patient data for verification
export const mockPatients = [
  {
    id: "P001",
    name: "Ramesh Kumar",
    room: "ICU-204",
    accessCode: "1234",
    department: "icu",
  },
  {
    id: "P002",
    name: "Priya Sharma",
    room: "OPD-102",
    accessCode: "5678",
    department: "opd",
  },
  {
    id: "P003",
    name: "Amit Singh",
    room: "Radiology-301",
    accessCode: "9012",
    department: "radiology",
  },
  {
    id: "P004",
    name: "Sunita Devi",
    room: "Emergency-05",
    accessCode: "3456",
    department: "emergency",
  },
  {
    id: "P005",
    name: "Rajesh Patel",
    room: "ICU-208",
    accessCode: "7890",
    department: "icu",
  },
]

export const relationOptions = [
  { value: "father", label: "Father" },
  { value: "mother", label: "Mother" },
  { value: "son", label: "Son" },
  { value: "daughter", label: "Daughter" },
  { value: "spouse", label: "Spouse" },
  { value: "brother", label: "Brother" },
  { value: "sister", label: "Sister" },
  { value: "friend", label: "Friend" },
  { value: "relative", label: "Other Relative" },
]

export const departments = [
  { id: "radiology", name: "Radiology", color: "#2563EB", icon: "scan" },
  { id: "icu", name: "ICU", color: "#EF4444", icon: "heart-pulse" },
  { id: "opd", name: "OPD", color: "#10B981", icon: "stethoscope" },
  { id: "emergency", name: "Emergency", color: "#EF4444", icon: "siren" },
  { id: "pharmacy", name: "Pharmacy", color: "#8b5cf6", icon: "pill" },
  { id: "laboratory", name: "Laboratory", color: "#f59e0b", icon: "flask" },
]

export const mockRoutes: Route[] = [
  {
    id: "route-radiology",
    name: "To Radiology",
    department: "Radiology",
    color: "#2563EB",
    steps: [
      {
        step: 1,
        instruction: "Walk past the main reception desk",
        image: "/images/reception.jpg",
        direction: "straight",
      },
      {
        step: 2,
        instruction: "Take the elevator to Floor 2",
        image: "/images/elevator.jpg",
        direction: "up",
      },
      {
        step: 3,
        instruction: "Turn right at the blue sign",
        image: "/images/hallway.jpg",
        direction: "right",
      },
      {
        step: 4,
        instruction: "Radiology department is on your left",
        image: "/images/radiology.jpg",
        direction: "destination",
      },
    ],
  },
  {
    id: "route-icu",
    name: "To ICU",
    department: "ICU",
    color: "#EF4444",
    steps: [
      {
        step: 1,
        instruction: "Go straight from the entrance",
        image: "/images/entrance.jpg",
        direction: "straight",
      },
      {
        step: 2,
        instruction: "Turn left at the emergency sign",
        image: "/images/emergency-sign.jpg",
        direction: "left",
      },
      {
        step: 3,
        instruction: "Take the elevator to Floor 3",
        image: "/images/elevator.jpg",
        direction: "up",
      },
      {
        step: 4,
        instruction: "ICU entrance is straight ahead",
        image: "/images/icu.jpg",
        direction: "destination",
      },
    ],
  },
  {
    id: "route-opd",
    name: "To OPD",
    department: "OPD",
    color: "#10B981",
    steps: [
      {
        step: 1,
        instruction: "Walk past reception on your right",
        image: "/images/reception.jpg",
        direction: "straight",
      },
      {
        step: 2,
        instruction: "Continue straight to the green corridor",
        image: "/images/corridor.jpg",
        direction: "straight",
      },
      {
        step: 3,
        instruction: "OPD is at the end of the corridor",
        image: "/images/opd.jpg",
        direction: "destination",
      },
    ],
  },
  {
    id: "route-pharmacy",
    name: "To Pharmacy",
    department: "Pharmacy",
    color: "#8b5cf6",
    steps: [
      {
        step: 1,
        instruction: "Turn right from the main entrance",
        image: "/images/entrance.jpg",
        direction: "right",
      },
      {
        step: 2,
        instruction: "Pharmacy is on your left",
        image: "/images/pharmacy.jpg",
        direction: "destination",
      },
    ],
  },
]

export const equipment = [
  {
    id: "wheelchair-1",
    type: "Wheelchair",
    available: true,
    location: "Ground Floor - Reception",
    floor: 0,
  },
  {
    id: "wheelchair-2",
    type: "Wheelchair",
    available: true,
    location: "Floor 1 - Near Elevator",
    floor: 1,
  },
  {
    id: "wheelchair-3",
    type: "Wheelchair",
    available: false,
    location: "Floor 2 - OPD",
    floor: 2,
  },
  {
    id: "oxygen-1",
    type: "Oxygen Cylinder",
    available: true,
    location: "Ground Floor - Emergency",
    floor: 0,
  },
  {
    id: "oxygen-2",
    type: "Oxygen Cylinder",
    available: false,
    location: "Floor 3 - ICU",
    floor: 3,
  },
  {
    id: "stretcher-1",
    type: "Stretcher",
    available: true,
    location: "Ground Floor - Emergency Bay",
    floor: 0,
  },
  {
    id: "stretcher-2",
    type: "Stretcher",
    available: true,
    location: "Floor 1 - Near Radiology",
    floor: 1,
  },
]
