"use client"

import { motion, AnimatePresence } from "framer-motion"
import { ShieldAlert, Phone, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface RestrictedAreaAlertProps {
  isOpen: boolean
  department: string
  onClose: () => void
}

export function RestrictedAreaAlert({
  isOpen,
  department,
  onClose,
}: RestrictedAreaAlertProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-card rounded-3xl p-8 max-w-md w-full shadow-2xl border border-border"
          >
            {/* Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.1 }}
              className="w-20 h-20 mx-auto mb-6 rounded-full bg-destructive/10 flex items-center justify-center"
            >
              <ShieldAlert className="w-10 h-10 text-destructive" />
            </motion.div>

            {/* Title */}
            <h2 className="text-2xl font-bold text-foreground text-center mb-2">
              Restricted Area
            </h2>
            
            {/* Department Badge */}
            <div className="flex justify-center mb-4">
              <span className="px-4 py-1 bg-destructive/10 text-destructive rounded-full text-sm font-semibold uppercase">
                {department}
              </span>
            </div>

            {/* Message */}
            <p className="text-muted-foreground text-center mb-6 text-lg">
              Authorization required to access this area. Please verify your access at the reception desk.
            </p>

            {/* Info Box */}
            <div className="bg-muted rounded-2xl p-4 mb-6">
              <p className="text-sm text-muted-foreground text-center">
                For security and patient safety, certain areas require verified visitor access. Please contact the reception for assistance.
              </p>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <Link href="/access" className="block">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-semibold text-lg flex items-center justify-center gap-2"
                >
                  <ShieldAlert className="w-5 h-5" />
                  Verify Access
                </motion.button>
              </Link>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  alert("Calling reception... Please wait.")
                }}
                className="w-full py-4 bg-muted text-foreground rounded-2xl font-semibold text-lg flex items-center justify-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Call Reception
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onClose}
                className="w-full py-3 text-muted-foreground font-medium flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Go Back
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
