"use client"

import { motion } from "framer-motion"
import { Clock, AlertTriangle } from "lucide-react"
import { useApp } from "@/context/AppContext"

interface AccessTimerProps {
  compact?: boolean
}

export function AccessTimer({ compact = false }: AccessTimerProps) {
  const { accessTimeRemaining, isAuthenticated } = useApp()

  if (!isAuthenticated) return null

  const hours = Math.floor(accessTimeRemaining / (1000 * 60 * 60))
  const minutes = Math.floor((accessTimeRemaining % (1000 * 60 * 60)) / (1000 * 60))
  const seconds = Math.floor((accessTimeRemaining % (1000 * 60)) / 1000)

  const isLowTime = accessTimeRemaining < 15 * 60 * 1000 // Less than 15 minutes
  const isCriticalTime = accessTimeRemaining < 5 * 60 * 1000 // Less than 5 minutes

  const formatTime = () => {
    if (hours > 0) {
      return `${hours}h ${minutes}m`
    }
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`
    }
    return `${seconds}s`
  }

  if (compact) {
    return (
      <motion.div
        animate={{
          backgroundColor: isCriticalTime
            ? "rgba(239, 68, 68, 0.1)"
            : isLowTime
            ? "rgba(245, 158, 11, 0.1)"
            : "rgba(16, 185, 129, 0.1)",
        }}
        className="flex items-center gap-2 px-3 py-2 rounded-xl"
      >
        <Clock
          className={`w-4 h-4 ${
            isCriticalTime
              ? "text-destructive"
              : isLowTime
              ? "text-amber-500"
              : "text-accent"
          }`}
        />
        <span
          className={`text-sm font-semibold ${
            isCriticalTime
              ? "text-destructive"
              : isLowTime
              ? "text-amber-500"
              : "text-accent"
          }`}
        >
          {formatTime()}
        </span>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl p-4 border-2 ${
        isCriticalTime
          ? "bg-destructive/5 border-destructive/20"
          : isLowTime
          ? "bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-800"
          : "bg-accent/5 border-accent/20"
      }`}
    >
      <div className="flex items-center gap-3">
        <div
          className={`p-2 rounded-xl ${
            isCriticalTime
              ? "bg-destructive/10"
              : isLowTime
              ? "bg-amber-100 dark:bg-amber-900/30"
              : "bg-accent/10"
          }`}
        >
          {isCriticalTime || isLowTime ? (
            <AlertTriangle
              className={`w-6 h-6 ${
                isCriticalTime ? "text-destructive" : "text-amber-500"
              }`}
            />
          ) : (
            <Clock className="w-6 h-6 text-accent" />
          )}
        </div>
        <div className="flex-1">
          <p
            className={`text-sm font-medium ${
              isCriticalTime
                ? "text-destructive"
                : isLowTime
                ? "text-amber-600 dark:text-amber-400"
                : "text-accent"
            }`}
          >
            Access Valid For
          </p>
          <p
            className={`text-2xl font-bold ${
              isCriticalTime
                ? "text-destructive"
                : isLowTime
                ? "text-amber-600 dark:text-amber-400"
                : "text-accent"
            }`}
          >
            {hours > 0 && `${hours}h `}
            {minutes}m {seconds}s
          </p>
        </div>
      </div>
      {(isCriticalTime || isLowTime) && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className={`mt-3 text-sm ${
            isCriticalTime
              ? "text-destructive"
              : "text-amber-600 dark:text-amber-400"
          }`}
        >
          {isCriticalTime
            ? "Your access will expire soon. Please complete your visit."
            : "Your access will expire in less than 15 minutes."}
        </motion.p>
      )}
    </motion.div>
  )
}
