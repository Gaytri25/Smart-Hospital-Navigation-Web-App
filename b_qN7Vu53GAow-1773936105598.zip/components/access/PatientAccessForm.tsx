"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  User,
  Users,
  Phone,
  Lock,
  ChevronDown,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Loader2,
} from "lucide-react"
import { SecureInputField } from "./SecureInputField"
import { useApp } from "@/context/AppContext"
import { mockPatients, relationOptions } from "@/lib/mockData"

interface PatientAccessFormProps {
  onSuccess: () => void
  targetDepartment?: string
}

export function PatientAccessForm({ onSuccess, targetDepartment }: PatientAccessFormProps) {
  const { grantAccess } = useApp()
  
  const [patientName, setPatientName] = useState("")
  const [relation, setRelation] = useState("")
  const [mobile, setMobile] = useState("")
  const [accessCode, setAccessCode] = useState("")
  
  const [isRelationOpen, setIsRelationOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showForgotCode, setShowForgotCode] = useState(false)
  
  const [errors, setErrors] = useState<{
    patientName?: string
    relation?: string
    mobile?: string
    accessCode?: string
  }>({})

  const validateForm = () => {
    const newErrors: typeof errors = {}
    
    if (!patientName.trim()) {
      newErrors.patientName = "Patient name is required"
    }
    if (!relation) {
      newErrors.relation = "Please select your relation"
    }
    if (!mobile.trim()) {
      newErrors.mobile = "Mobile number is required"
    } else if (!/^\d{10}$/.test(mobile.replace(/\D/g, ""))) {
      newErrors.mobile = "Enter a valid 10-digit mobile number"
    }
    if (!accessCode.trim()) {
      newErrors.accessCode = "Access code is required"
    } else if (accessCode.length < 4) {
      newErrors.accessCode = "Access code must be at least 4 digits"
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async () => {
    setError("")
    
    if (!validateForm()) return
    
    setIsLoading(true)
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    // Find matching patient
    const patient = mockPatients.find(
      (p) =>
        p.name.toLowerCase() === patientName.toLowerCase().trim() &&
        p.accessCode === accessCode
    )
    
    if (patient) {
      // Check if target department matches (if specified)
      if (targetDepartment && patient.department.toLowerCase() !== targetDepartment.toLowerCase()) {
        setError(`This access code is for ${patient.department.toUpperCase()}, not ${targetDepartment.toUpperCase()}`)
        setIsLoading(false)
        return
      }
      
      grantAccess({
        patientName: patient.name,
        patientRoom: patient.room,
        visitorName: patientName,
        relation,
        mobile,
        accessGrantedAt: Date.now(),
        expiryTime: Date.now() + 2 * 60 * 60 * 1000,
      })
      
      setIsLoading(false)
      onSuccess()
    } else {
      setError("Invalid access code. Please contact reception for assistance.")
      setIsLoading(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Error Alert */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-destructive/10 border-2 border-destructive/20 rounded-2xl p-4 flex items-start gap-3"
          >
            <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-destructive font-semibold">{error}</p>
              <button
                onClick={() => setShowForgotCode(true)}
                className="text-sm text-destructive/80 underline mt-1"
              >
                Forgot your access code?
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Forgot Code Info */}
      <AnimatePresence>
        {showForgotCode && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-primary/5 border-2 border-primary/20 rounded-2xl p-4"
          >
            <div className="flex items-start gap-3">
              <HelpCircle className="w-6 h-6 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-foreground font-semibold mb-1">
                  Need Help with Access Code?
                </p>
                <p className="text-muted-foreground text-sm mb-3">
                  Please visit the reception desk with a valid ID. The staff will verify your identity and provide a new access code.
                </p>
                <p className="text-muted-foreground text-sm">
                  Reception Hours: 24/7
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowForgotCode(false)}
              className="mt-3 text-sm text-primary font-medium"
            >
              Got it, close this
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Patient Name */}
      <SecureInputField
        label="Patient Name"
        placeholder="Enter patient's full name"
        value={patientName}
        onChange={(v) => {
          setPatientName(v)
          setErrors((e) => ({ ...e, patientName: undefined }))
        }}
        icon={User}
        error={errors.patientName}
        disabled={isLoading}
      />

      {/* Relation Dropdown */}
      <div className="space-y-2">
        <label className="block text-base font-semibold text-foreground">
          Your Relation
        </label>
        <div className="relative">
          <motion.button
            type="button"
            onClick={() => !isLoading && setIsRelationOpen(!isRelationOpen)}
            className={`w-full flex items-center bg-background border-2 rounded-2xl overflow-hidden transition-colors ${
              errors.relation
                ? "border-destructive"
                : isRelationOpen
                ? "border-primary"
                : "border-border"
            } ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            <div className="pl-4 pr-2 py-4">
              <Users
                className={`w-6 h-6 ${
                  errors.relation
                    ? "text-destructive"
                    : isRelationOpen
                    ? "text-primary"
                    : "text-muted-foreground"
                }`}
              />
            </div>
            <span
              className={`flex-1 text-left py-4 text-lg ${
                relation ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {relation
                ? relationOptions.find((r) => r.value === relation)?.label
                : "Select your relation"}
            </span>
            <div className="pr-4 py-4">
              <ChevronDown
                className={`w-6 h-6 text-muted-foreground transition-transform ${
                  isRelationOpen ? "rotate-180" : ""
                }`}
              />
            </div>
          </motion.button>

          <AnimatePresence>
            {isRelationOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute z-10 w-full mt-2 bg-card border-2 border-border rounded-2xl shadow-xl overflow-hidden"
              >
                {relationOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      setRelation(option.value)
                      setIsRelationOpen(false)
                      setErrors((e) => ({ ...e, relation: undefined }))
                    }}
                    className={`w-full text-left px-4 py-3 text-lg transition-colors hover:bg-muted ${
                      relation === option.value
                        ? "bg-primary/5 text-primary font-semibold"
                        : "text-foreground"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {errors.relation && (
          <motion.p
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-destructive text-sm font-medium"
          >
            {errors.relation}
          </motion.p>
        )}
      </div>

      {/* Mobile Number */}
      <SecureInputField
        label="Mobile Number"
        placeholder="Enter your mobile number"
        value={mobile}
        onChange={(v) => {
          // Only allow digits
          const cleaned = v.replace(/\D/g, "").slice(0, 10)
          setMobile(cleaned)
          setErrors((e) => ({ ...e, mobile: undefined }))
        }}
        type="tel"
        icon={Phone}
        error={errors.mobile}
        disabled={isLoading}
        maxLength={10}
      />

      {/* Secure Access Code */}
      <SecureInputField
        label="Secure Access Code"
        placeholder="Enter 4-digit access code"
        value={accessCode}
        onChange={(v) => {
          const cleaned = v.replace(/\D/g, "").slice(0, 6)
          setAccessCode(cleaned)
          setErrors((e) => ({ ...e, accessCode: undefined }))
          setError("")
        }}
        type="password"
        icon={Lock}
        error={errors.accessCode}
        disabled={isLoading}
        maxLength={6}
      />

      {/* Security Notice */}
      <div className="flex items-start gap-2 text-muted-foreground bg-muted rounded-xl p-3">
        <Lock className="w-4 h-4 mt-0.5 flex-shrink-0" />
        <p className="text-sm">
          Your information is secured and will only be used for visitor verification purposes.
        </p>
      </div>

      {/* Submit Button */}
      <motion.button
        whileHover={{ scale: isLoading ? 1 : 1.02 }}
        whileTap={{ scale: isLoading ? 1 : 0.98 }}
        onClick={handleSubmit}
        disabled={isLoading}
        className="w-full py-5 bg-primary text-primary-foreground rounded-2xl font-semibold text-xl flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-6 h-6 animate-spin" />
            Verifying...
          </>
        ) : (
          <>
            <CheckCircle className="w-6 h-6" />
            Verify Access
          </>
        )}
      </motion.button>

      {/* Help Link */}
      <div className="text-center">
        <button
          onClick={() => setShowForgotCode(!showForgotCode)}
          className="text-primary font-medium text-base inline-flex items-center gap-2"
        >
          <HelpCircle className="w-5 h-5" />
          Need help? Contact Reception
        </button>
      </div>
    </motion.div>
  )
}
