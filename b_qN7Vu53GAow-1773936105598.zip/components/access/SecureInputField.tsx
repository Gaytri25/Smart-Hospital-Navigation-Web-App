"use client"

import { useState, forwardRef } from "react"
import { motion } from "framer-motion"
import { Eye, EyeOff, LucideIcon } from "lucide-react"

interface SecureInputFieldProps {
  label: string
  placeholder: string
  value: string
  onChange: (value: string) => void
  type?: "text" | "password" | "tel"
  icon: LucideIcon
  error?: string
  disabled?: boolean
  maxLength?: number
}

export const SecureInputField = forwardRef<HTMLInputElement, SecureInputFieldProps>(
  function SecureInputField(
    {
      label,
      placeholder,
      value,
      onChange,
      type = "text",
      icon: Icon,
      error,
      disabled,
      maxLength,
    },
    ref
  ) {
    const [showPassword, setShowPassword] = useState(false)
    const [isFocused, setIsFocused] = useState(false)

    const inputType = type === "password" && showPassword ? "text" : type

    return (
      <div className="space-y-2">
        <label className="block text-base font-semibold text-foreground">
          {label}
        </label>
        <motion.div
          animate={{
            borderColor: error
              ? "var(--destructive)"
              : isFocused
              ? "var(--primary)"
              : "var(--border)",
            boxShadow: isFocused
              ? "0 0 0 3px rgba(37, 99, 235, 0.1)"
              : "none",
          }}
          className={`relative flex items-center bg-background border-2 rounded-2xl overflow-hidden transition-colors ${
            error ? "border-destructive" : "border-border"
          }`}
        >
          <div className="pl-4 pr-2 py-4">
            <Icon
              className={`w-6 h-6 ${
                error
                  ? "text-destructive"
                  : isFocused
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            />
          </div>
          <input
            ref={ref}
            type={inputType}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            maxLength={maxLength}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            className="flex-1 py-4 pr-4 text-lg bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ WebkitUserSelect: type === "password" ? "none" : "auto" }}
          />
          {type === "password" && (
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="pr-4 py-4 text-muted-foreground hover:text-foreground transition-colors"
              tabIndex={-1}
            >
              {showPassword ? (
                <EyeOff className="w-6 h-6" />
              ) : (
                <Eye className="w-6 h-6" />
              )}
            </button>
          )}
        </motion.div>
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-destructive text-sm font-medium flex items-center gap-1"
          >
            {error}
          </motion.p>
        )}
      </div>
    )
  }
)
