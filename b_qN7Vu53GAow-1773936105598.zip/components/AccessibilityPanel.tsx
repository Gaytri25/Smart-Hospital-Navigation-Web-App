"use client"

import { motion } from "framer-motion"
import { Contrast, Volume2, Type, X } from "lucide-react"
import { useApp } from "@/context/AppContext"
import { translations } from "@/lib/translations"

interface AccessibilityPanelProps {
  isOpen: boolean
  onClose: () => void
}

export function AccessibilityPanel({ isOpen, onClose }: AccessibilityPanelProps) {
  const { language, isHighContrast, setIsHighContrast } = useApp()
  const t = translations[language].accessibility

  if (!isOpen) return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
      className="fixed right-0 top-0 bottom-0 w-80 bg-card shadow-2xl z-50 p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-foreground">Accessibility</h2>
        <button
          onClick={onClose}
          className="p-2 rounded-xl hover:bg-muted transition-colors"
        >
          <X className="w-6 h-6 text-muted-foreground" />
        </button>
      </div>

      <div className="space-y-4">
        {/* High Contrast Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-2xl">
          <div className="flex items-center gap-3">
            <Contrast className="w-6 h-6 text-primary" />
            <span className="font-medium text-foreground">{t.highContrast}</span>
          </div>
          <button
            onClick={() => setIsHighContrast(!isHighContrast)}
            className={`w-14 h-8 rounded-full transition-all ${
              isHighContrast ? "bg-primary" : "bg-border"
            }`}
          >
            <motion.div
              animate={{ x: isHighContrast ? 24 : 4 }}
              className="w-6 h-6 bg-card rounded-full shadow-md"
            />
          </button>
        </div>

        {/* Voice Toggle */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-2xl">
          <div className="flex items-center gap-3">
            <Volume2 className="w-6 h-6 text-primary" />
            <span className="font-medium text-foreground">{t.voiceEnabled}</span>
          </div>
          <button className="w-14 h-8 rounded-full bg-primary transition-all">
            <motion.div
              animate={{ x: 24 }}
              className="w-6 h-6 bg-card rounded-full shadow-md"
            />
          </button>
        </div>

        {/* Text Size */}
        <div className="p-4 bg-muted rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <Type className="w-6 h-6 text-primary" />
            <span className="font-medium text-foreground">{t.increaseText}</span>
          </div>
          <div className="flex gap-2">
            {["S", "M", "L", "XL"].map((size) => (
              <button
                key={size}
                className={`flex-1 py-2 rounded-xl font-semibold transition-all ${
                  size === "L"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-muted-foreground hover:bg-card/80"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  )
}
