"use client"

import { useState, useRef, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Upload, X, RefreshCw, Check, AlertCircle, Image as ImageIcon } from "lucide-react"

interface UploadBoxProps {
  image: string | null
  onImageChange: (image: string | null) => void
  disabled?: boolean
}

export function UploadBox({ image, onImageChange, disabled }: UploadBoxProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadState, setUploadState] = useState<"idle" | "uploading" | "success" | "error">("idle")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    if (!disabled) setIsDragging(true)
  }, [disabled])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const processFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) {
      setUploadState("error")
      setTimeout(() => setUploadState("idle"), 2000)
      return
    }

    setUploadState("uploading")
    
    // Simulate upload delay for realistic feedback
    const reader = new FileReader()
    reader.onload = (e) => {
      setTimeout(() => {
        onImageChange(e.target?.result as string)
        setUploadState("success")
        setTimeout(() => setUploadState("idle"), 1500)
      }, 800)
    }
    reader.onerror = () => {
      setUploadState("error")
      setTimeout(() => setUploadState("idle"), 2000)
    }
    reader.readAsDataURL(file)
  }, [onImageChange])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    if (disabled) return

    const file = e.dataTransfer.files[0]
    if (file) processFile(file)
  }, [disabled, processFile])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) processFile(file)
    // Reset input for re-selection
    e.target.value = ""
  }, [processFile])

  const handleRemove = useCallback(() => {
    onImageChange(null)
    setUploadState("idle")
  }, [onImageChange])

  const handleReplace = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  if (image) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative rounded-2xl overflow-hidden border-2 border-border bg-muted"
      >
        <img
          src={image}
          alt="Step preview"
          className="w-full h-40 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-3 right-3 flex gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleRemove}
            className="flex-1 py-2.5 px-4 bg-destructive text-destructive-foreground rounded-xl text-sm font-medium flex items-center justify-center gap-2"
          >
            <X className="w-4 h-4" />
            Remove
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleReplace}
            className="flex-1 py-2.5 px-4 bg-card text-foreground rounded-xl text-sm font-medium flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Replace
          </motion.button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </motion.div>
    )
  }

  return (
    <div>
      <motion.div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !disabled && fileInputRef.current?.click()}
        animate={{
          borderColor: isDragging ? "var(--primary)" : "var(--border)",
          backgroundColor: isDragging ? "var(--primary)" : "var(--muted)",
        }}
        className={`
          relative h-36 rounded-2xl border-2 border-dashed 
          flex flex-col items-center justify-center gap-2 cursor-pointer
          transition-colors duration-200
          ${disabled ? "opacity-50 cursor-not-allowed" : "hover:border-primary/50 hover:bg-primary/5"}
          ${isDragging ? "border-primary bg-primary/10" : "border-border bg-muted"}
        `}
      >
        <AnimatePresence mode="wait">
          {uploadState === "uploading" ? (
            <motion.div
              key="uploading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-2"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-10 h-10 rounded-full border-3 border-primary border-t-transparent"
              />
              <span className="text-sm font-medium text-primary">Uploading image...</span>
            </motion.div>
          ) : uploadState === "success" ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-2"
            >
              <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center">
                <Check className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="text-sm font-medium text-accent">Uploaded successfully</span>
            </motion.div>
          ) : uploadState === "error" ? (
            <motion.div
              key="error"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-2"
            >
              <div className="w-10 h-10 rounded-full bg-destructive flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-destructive-foreground" />
              </div>
              <span className="text-sm font-medium text-destructive">Upload failed</span>
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-12 h-12 rounded-full ${isDragging ? "bg-primary" : "bg-primary/10"} flex items-center justify-center transition-colors`}>
                <ImageIcon className={`w-6 h-6 ${isDragging ? "text-primary-foreground" : "text-primary"}`} />
              </div>
              <div className="text-center">
                <p className={`text-sm font-medium ${isDragging ? "text-primary" : "text-foreground"}`}>
                  {isDragging ? "Drop image here" : "Click or drag image here"}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">PNG, JPG up to 5MB</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        disabled={disabled}
        className="hidden"
      />
    </div>
  )
}
