"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import {
  Trash2,
  ChevronUp,
  ChevronDown,
  Mic,
  MicOff,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  MoveRight,
  MapPin,
} from "lucide-react"
import { UploadBox } from "./UploadBox"

export interface RouteStepData {
  id: string
  instruction: string
  direction: "straight" | "left" | "right" | "up" | "down" | "destination"
  image: string | null
}

interface RouteStepCardProps {
  step: RouteStepData
  index: number
  totalSteps: number
  onUpdate: (id: string, field: keyof RouteStepData, value: string | null) => void
  onDelete: (id: string) => void
  onMoveUp: (id: string) => void
  onMoveDown: (id: string) => void
}

const directionOptions = [
  { value: "straight", label: "Go Straight", icon: MoveRight },
  { value: "left", label: "Turn Left", icon: ArrowLeft },
  { value: "right", label: "Turn Right", icon: ArrowRight },
  { value: "up", label: "Go Up (Stairs/Elevator)", icon: ArrowUp },
  { value: "down", label: "Go Down", icon: ArrowDown },
  { value: "destination", label: "Destination", icon: MapPin },
]

const suggestions = [
  "Walk straight ahead",
  "Turn left at the corridor",
  "Turn right at the reception",
  "Take the elevator to floor",
  "Use the stairs on your left",
  "Pass through the double doors",
  "You will see a sign for",
  "Continue past the waiting area",
]

export function RouteStepCard({
  step,
  index,
  totalSteps,
  onUpdate,
  onDelete,
  onMoveUp,
  onMoveDown,
}: RouteStepCardProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    // Initialize speech recognition
    if (typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = "en-US"

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript
        onUpdate(step.id, "instruction", transcript)
        setIsRecording(false)
      }

      recognitionRef.current.onerror = () => {
        setIsRecording(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
    }
  }, [step.id, onUpdate])

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) return

    if (isRecording) {
      recognitionRef.current.stop()
      setIsRecording(false)
    } else {
      recognitionRef.current.start()
      setIsRecording(true)
    }
  }

  const DirectionIcon = directionOptions.find((d) => d.value === step.direction)?.icon || MoveRight

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20, height: 0 }}
      layout
      className="bg-card rounded-3xl border border-border overflow-hidden"
    >
      {/* Step Header */}
      <div className="p-4 pb-0 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
            {index + 1}
          </div>
          <div>
            <h4 className="font-semibold text-foreground">Step {index + 1}</h4>
            <p className="text-xs text-muted-foreground">
              {step.instruction ? step.instruction.slice(0, 30) + (step.instruction.length > 30 ? "..." : "") : "Add instruction"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onMoveUp(step.id)}
            disabled={index === 0}
            className={`p-2 rounded-xl transition-colors ${
              index === 0
                ? "text-muted-foreground/30 cursor-not-allowed"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            <ChevronUp className="w-5 h-5" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onMoveDown(step.id)}
            disabled={index === totalSteps - 1}
            className={`p-2 rounded-xl transition-colors ${
              index === totalSteps - 1
                ? "text-muted-foreground/30 cursor-not-allowed"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            <ChevronDown className="w-5 h-5" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onDelete(step.id)}
            className="p-2 rounded-xl text-destructive hover:bg-destructive/10 transition-colors"
          >
            <Trash2 className="w-5 h-5" />
          </motion.button>
        </div>
      </div>

      {/* Step Content */}
      <div className="p-4 space-y-4">
        {/* Instruction Input with Voice */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground flex items-center gap-2">
            Instruction
            <span className="text-xs text-muted-foreground font-normal">(What should the patient do?)</span>
          </label>
          <div className="relative">
            <input
              type="text"
              value={step.instruction}
              onChange={(e) => onUpdate(step.id, "instruction", e.target.value)}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              placeholder="e.g., Turn right at the elevator"
              className="w-full px-4 py-3 pr-24 bg-background rounded-xl border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-base"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowSuggestions(!showSuggestions)}
                className="p-2 rounded-lg text-muted-foreground hover:bg-muted hover:text-primary transition-colors"
                title="Show suggestions"
              >
                <Sparkles className="w-4 h-4" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={toggleVoiceInput}
                className={`p-2 rounded-lg transition-colors ${
                  isRecording
                    ? "bg-destructive text-destructive-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-primary"
                }`}
                title={isRecording ? "Stop recording" : "Voice input"}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </motion.button>
            </div>
          </div>

          {/* Suggestions Dropdown */}
          {showSuggestions && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-xl border border-border shadow-lg p-2 space-y-1"
            >
              <p className="text-xs text-muted-foreground px-2 py-1">Quick suggestions:</p>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.map((suggestion, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      onUpdate(step.id, "instruction", suggestion)
                      setShowSuggestions(false)
                    }}
                    className="px-3 py-1.5 bg-muted text-foreground rounded-lg text-sm hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* Direction Selector */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Direction</label>
          <div className="grid grid-cols-3 gap-2">
            {directionOptions.map((option) => {
              const Icon = option.icon
              const isSelected = step.direction === option.value
              return (
                <motion.button
                  key={option.value}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onUpdate(step.id, "direction", option.value)}
                  className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1.5 transition-all ${
                    isSelected
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-background text-muted-foreground hover:border-primary/50"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{option.label.split(" ")[0]}</span>
                </motion.button>
              )
            })}
          </div>
        </div>

        {/* Image Upload */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground flex items-center gap-2">
            Reference Image
            <span className="text-xs text-muted-foreground font-normal">(Helps patients identify location)</span>
          </label>
          <UploadBox
            image={step.image}
            onImageChange={(img) => onUpdate(step.id, "image", img)}
          />
        </div>
      </div>

      {/* Step Status Indicator */}
      <div className="px-4 pb-4">
        <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm ${
          step.instruction && step.image
            ? "bg-accent/10 text-accent"
            : step.instruction
            ? "bg-amber-100 text-amber-700"
            : "bg-muted text-muted-foreground"
        }`}>
          <div className={`w-2 h-2 rounded-full ${
            step.instruction && step.image
              ? "bg-accent"
              : step.instruction
              ? "bg-amber-500"
              : "bg-muted-foreground"
          }`} />
          {step.instruction && step.image
            ? "Step complete"
            : step.instruction
            ? "Add image to complete"
            : "Add instruction and image"}
        </div>
      </div>
    </motion.div>
  )
}
