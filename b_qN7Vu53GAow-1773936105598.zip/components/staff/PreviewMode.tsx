"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  X,
  ChevronLeft,
  ChevronRight,
  Volume2,
  MapPin,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  MoveRight,
} from "lucide-react"
import { RouteStepData } from "./RouteStepCard"

interface PreviewModeProps {
  routeName: string
  steps: RouteStepData[]
  onClose: () => void
}

const directionIcons: Record<string, React.ElementType> = {
  straight: MoveRight,
  left: ArrowLeft,
  right: ArrowRight,
  up: ArrowUp,
  down: ArrowDown,
  destination: MapPin,
}

export function PreviewMode({ routeName, steps, onClose }: PreviewModeProps) {
  const [currentStep, setCurrentStep] = useState(0)

  const step = steps[currentStep]
  const DirectionIcon = directionIcons[step?.direction] || MoveRight
  const progress = ((currentStep + 1) / steps.length) * 100

  const speakInstruction = () => {
    if ("speechSynthesis" in window && step?.instruction) {
      const utterance = new SpeechSynthesisUtterance(step.instruction)
      utterance.rate = 0.9
      utterance.pitch = 1
      speechSynthesis.speak(utterance)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-background"
    >
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-lg">
                Preview Mode
              </span>
              <h2 className="font-semibold text-foreground truncate">{routeName}</h2>
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-2 rounded-xl bg-muted text-foreground hover:bg-muted/80 transition-colors"
            >
              <X className="w-5 h-5" />
            </motion.button>
          </div>

          {/* Progress Bar */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <span className="text-sm font-medium text-foreground whitespace-nowrap">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-lg mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            {/* Step Card */}
            <div className="bg-card rounded-3xl border border-border overflow-hidden">
              {/* Step Image */}
              {step?.image ? (
                <div className="relative aspect-video">
                  <img
                    src={step.image}
                    alt={`Step ${currentStep + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-bold">
                        {currentStep + 1}
                      </div>
                      <div className="px-3 py-1.5 bg-white/90 rounded-lg">
                        <DirectionIcon className="w-5 h-5 text-primary" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="aspect-video bg-muted flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No image for this step</p>
                  </div>
                </div>
              )}

              {/* Instruction */}
              <div className="p-6">
                <div className="flex items-start gap-4">
                  <div className="flex-1">
                    <p className="text-xl font-semibold text-foreground leading-relaxed">
                      {step?.instruction || "No instruction provided"}
                    </p>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={speakInstruction}
                    className="p-3 rounded-xl bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                  >
                    <Volume2 className="w-6 h-6" />
                  </motion.button>
                </div>
              </div>
            </div>

            {/* Navigation Direction Visual */}
            <div className="flex items-center justify-center">
              <div className="flex items-center gap-3 px-6 py-4 bg-card rounded-2xl border border-border">
                <DirectionIcon className="w-8 h-8 text-primary" />
                <span className="text-lg font-medium text-foreground capitalize">
                  {step?.direction === "destination" ? "You have arrived!" : step?.direction?.replace("_", " ")}
                </span>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t border-border">
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className={`flex-1 py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 text-lg ${
                currentStep === 0
                  ? "bg-muted text-muted-foreground cursor-not-allowed"
                  : "bg-secondary text-secondary-foreground"
              }`}
            >
              <ChevronLeft className="w-6 h-6" />
              Previous
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
              disabled={currentStep === steps.length - 1}
              className={`flex-1 py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 text-lg ${
                currentStep === steps.length - 1
                  ? "bg-accent text-accent-foreground"
                  : "bg-primary text-primary-foreground"
              }`}
            >
              {currentStep === steps.length - 1 ? "Arrived!" : "Next"}
              {currentStep < steps.length - 1 && <ChevronRight className="w-6 h-6" />}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
