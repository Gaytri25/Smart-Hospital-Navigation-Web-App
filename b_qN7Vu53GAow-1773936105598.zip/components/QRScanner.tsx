"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { Camera, XCircle, Loader2 } from "lucide-react"
import { useApp } from "@/context/AppContext"
import { translations } from "@/lib/translations"

interface QRScannerProps {
  onScan: (data: string) => void
}

export function QRScanner({ onScan }: QRScannerProps) {
  const { language } = useApp()
  const t = translations[language].scanner
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setHasPermission(true)
      setIsScanning(true)

      // Simulate QR detection after 3 seconds (demo purpose)
      setTimeout(() => {
        onScan("route-radiology")
      }, 3000)
    } catch {
      setHasPermission(false)
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setIsScanning(false)
  }

  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  if (hasPermission === false) {
    return (
      <div className="bg-card rounded-3xl p-8 text-center">
        <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-destructive/10 flex items-center justify-center">
          <XCircle className="w-10 h-10 text-destructive" />
        </div>
        <h3 className="text-xl font-bold text-foreground mb-2">
          {t.permissionDenied}
        </h3>
        <p className="text-muted-foreground mb-6">
          Please enable camera access in your browser settings
        </p>
        <button
          onClick={startCamera}
          className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold"
        >
          {t.enableCamera}
        </button>
      </div>
    )
  }

  return (
    <div className="relative">
      {!isScanning ? (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={startCamera}
          className="w-full bg-card rounded-3xl p-8 flex flex-col items-center gap-4 transition-all hover:shadow-lg border-2 border-dashed border-primary/30 hover:border-primary"
        >
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
            <Camera className="w-12 h-12 text-primary" />
          </div>
          <span className="text-xl font-bold text-foreground">{t.title}</span>
          <span className="text-muted-foreground">{t.instructions}</span>
        </motion.button>
      ) : (
        <div className="relative rounded-3xl overflow-hidden bg-card">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full aspect-square object-cover"
          />
          
          {/* Scanning overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            {/* Corner markers */}
            <div className="relative w-64 h-64">
              <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-primary rounded-tl-lg" />
              <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-primary rounded-tr-lg" />
              <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-primary rounded-bl-lg" />
              <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-primary rounded-br-lg" />
              
              {/* Scanning line animation */}
              <motion.div
                animate={{ y: [0, 240, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="absolute left-2 right-2 h-1 bg-primary/80 rounded-full shadow-lg"
                style={{ boxShadow: "0 0 20px 5px rgba(37, 99, 235, 0.5)" }}
              />
            </div>
          </div>

          {/* Status */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2">
            <div className="flex items-center gap-2 px-4 py-2 bg-card/90 backdrop-blur-sm rounded-full">
              <Loader2 className="w-5 h-5 text-primary animate-spin" />
              <span className="font-medium text-foreground">{t.scanning}</span>
            </div>
          </div>

          {/* Close button */}
          <button
            onClick={stopCamera}
            className="absolute top-4 right-4 p-3 bg-card/90 backdrop-blur-sm rounded-full"
          >
            <XCircle className="w-6 h-6 text-muted-foreground" />
          </button>
        </div>
      )}
    </div>
  )
}
