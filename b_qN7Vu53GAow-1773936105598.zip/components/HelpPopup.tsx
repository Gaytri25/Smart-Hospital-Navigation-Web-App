"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Phone, RotateCcw, MapPin, X, AlertCircle } from "lucide-react"
import { useApp } from "@/context/AppContext"
import { translations } from "@/lib/translations"

interface HelpPopupProps {
  isOpen: boolean
  onClose: () => void
  onCallStaff: () => void
  onRestart: () => void
  onShowLastStep: () => void
}

export function HelpPopup({
  isOpen,
  onClose,
  onCallStaff,
  onRestart,
  onShowLastStep,
}: HelpPopupProps) {
  const { language } = useApp()
  const t = translations[language].help

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50"
          />

          {/* Popup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ 
              opacity: 1, 
              scale: 1, 
              y: 0,
              transition: {
                type: "spring",
                duration: 0.5,
              }
            }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-md z-50"
          >
            <motion.div
              animate={{
                x: [0, -5, 5, -5, 5, 0],
              }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-card rounded-3xl shadow-2xl overflow-hidden border-2 border-destructive"
            >
              {/* Header */}
              <div className="bg-destructive/10 px-6 py-5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-destructive/20 flex items-center justify-center">
                    <AlertCircle className="w-7 h-7 text-destructive" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-foreground">{t.title}</h2>
                    <p className="text-muted-foreground">{t.subtitle}</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 rounded-xl hover:bg-muted transition-colors"
                >
                  <X className="w-6 h-6 text-muted-foreground" />
                </button>
              </div>

              {/* Actions */}
              <div className="p-6 space-y-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onCallStaff}
                  className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-destructive text-destructive-foreground font-semibold text-lg transition-all hover:bg-destructive/90"
                >
                  <Phone className="w-6 h-6" />
                  {t.callStaff}
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onRestart}
                  className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-primary text-primary-foreground font-semibold text-lg transition-all hover:bg-primary/90"
                >
                  <RotateCcw className="w-6 h-6" />
                  {t.restartDirections}
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onShowLastStep}
                  className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-muted text-foreground font-semibold text-lg transition-all hover:bg-muted/80"
                >
                  <MapPin className="w-6 h-6" />
                  {t.showLastStep}
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
