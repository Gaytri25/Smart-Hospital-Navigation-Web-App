"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Volume2, VolumeX, Loader2 } from "lucide-react"
import { useApp, Language } from "@/context/AppContext"

interface VoiceButtonProps {
  text: string
  className?: string
  size?: "sm" | "md" | "lg"
}

const languageMap: Record<Language, string> = {
  en: "en-US",
  hi: "hi-IN",
  mr: "mr-IN",
}

export function VoiceButton({ text, className = "", size = "md" }: VoiceButtonProps) {
  const { language } = useApp()
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isSupported, setIsSupported] = useState(true)

  useEffect(() => {
    setIsSupported("speechSynthesis" in window)
  }, [])

  const speak = () => {
    if (!isSupported) return

    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
      return
    }

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = languageMap[language]
    utterance.rate = 0.9
    utterance.pitch = 1

    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    window.speechSynthesis.speak(utterance)
  }

  const sizeClasses = {
    sm: "min-h-[44px] px-4 py-2 text-sm",
    md: "min-h-[52px] px-6 py-3 text-base",
    lg: "min-h-[60px] px-8 py-4 text-lg",
  }

  const iconSizes = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  }

  if (!isSupported) {
    return null
  }

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={speak}
      className={`flex items-center justify-center gap-2 rounded-2xl font-semibold transition-all ${
        isSpeaking
          ? "bg-accent text-accent-foreground"
          : "bg-primary text-primary-foreground hover:bg-primary/90"
      } ${sizeClasses[size]} ${className}`}
    >
      {isSpeaking ? (
        <>
          <Loader2 className={`${iconSizes[size]} animate-spin`} />
          <span>Speaking...</span>
        </>
      ) : (
        <>
          <Volume2 className={iconSizes[size]} />
          <span>Play Voice Guide</span>
        </>
      )}
    </motion.button>
  )
}
