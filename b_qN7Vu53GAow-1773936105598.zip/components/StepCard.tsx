"use client"

import { motion } from "framer-motion"
import { NavigationStep } from "@/context/AppContext"
import {
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  MoveUp,
  MapPin,
  CircleArrowUp,
} from "lucide-react"
import Image from "next/image"

interface StepCardProps {
  step: NavigationStep
  isActive: boolean
  isCompleted: boolean
  color: string
  totalSteps: number
}

const directionIcons = {
  straight: MoveUp,
  left: ArrowLeft,
  right: ArrowRight,
  up: CircleArrowUp,
  down: ArrowDown,
  destination: MapPin,
}

const directionLabels = {
  straight: "Go Straight",
  left: "Turn Left",
  right: "Turn Right",
  up: "Go Up",
  down: "Go Down",
  destination: "Destination",
}

export function StepCard({
  step,
  isActive,
  isCompleted,
  color,
  totalSteps,
}: StepCardProps) {
  const DirectionIcon = directionIcons[step.direction]

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: step.step * 0.1 }}
      className={`relative rounded-2xl overflow-hidden transition-all duration-300 ${
        isActive
          ? "ring-4 shadow-xl scale-[1.02]"
          : isCompleted
          ? "opacity-60"
          : "opacity-40"
      }`}
      style={{
        borderColor: isActive ? color : "transparent",
        ringColor: isActive ? color : "transparent",
      }}
    >
      {/* Step Number Badge */}
      <div
        className="absolute top-4 left-4 z-10 w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold shadow-lg"
        style={{
          backgroundColor: isCompleted ? "#10B981" : color,
          color: "white",
        }}
      >
        {isCompleted ? "✓" : step.step}
      </div>

      {/* Progress indicator */}
      <div className="absolute top-4 right-4 z-10 bg-card/90 backdrop-blur-sm px-3 py-1 rounded-full">
        <span className="text-sm font-medium text-foreground">
          {step.step} / {totalSteps}
        </span>
      </div>

      {/* Image */}
      <div className="relative h-48 bg-muted">
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10">
          <DirectionIcon
            className="w-24 h-24 opacity-20"
            style={{ color }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="bg-card p-5">
        {/* Direction Badge */}
        <div
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl mb-3"
          style={{ backgroundColor: `${color}20`, color }}
        >
          <DirectionIcon className="w-5 h-5" />
          <span className="font-semibold text-sm">
            {directionLabels[step.direction]}
          </span>
        </div>

        {/* Instruction */}
        <p className="text-lg font-medium text-foreground leading-relaxed">
          {step.instruction}
        </p>
      </div>
    </motion.div>
  )
}
