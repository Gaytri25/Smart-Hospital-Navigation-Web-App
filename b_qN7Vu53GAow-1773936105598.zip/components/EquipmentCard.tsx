"use client"

import { motion } from "framer-motion"
import { MapPin, CheckCircle, XCircle } from "lucide-react"
import { useApp } from "@/context/AppContext"
import { translations } from "@/lib/translations"

interface EquipmentCardProps {
  id: string
  type: string
  available: boolean
  location: string
  floor: number
  index: number
}

export function EquipmentCard({
  type,
  available,
  location,
  floor,
  index,
}: EquipmentCardProps) {
  const { language } = useApp()
  const t = translations[language].equipment

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className={`bg-card rounded-2xl p-5 shadow-sm border transition-all hover:shadow-md ${
        available ? "border-accent/30" : "border-destructive/30"
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-foreground">{type}</h3>
          <p className="text-sm text-muted-foreground">Floor {floor}</p>
        </div>
        <div
          className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${
            available
              ? "bg-accent/10 text-accent"
              : "bg-destructive/10 text-destructive"
          }`}
        >
          {available ? (
            <>
              <CheckCircle className="w-4 h-4" />
              {t.available}
            </>
          ) : (
            <>
              <XCircle className="w-4 h-4" />
              {t.inUse}
            </>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 text-muted-foreground">
        <MapPin className="w-4 h-4 flex-shrink-0" />
        <span className="text-sm">{location}</span>
      </div>

      {available && (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full mt-4 py-3 px-4 bg-primary text-primary-foreground rounded-xl font-semibold text-base transition-all hover:bg-primary/90"
        >
          Navigate to Equipment
        </motion.button>
      )}
    </motion.div>
  )
}
