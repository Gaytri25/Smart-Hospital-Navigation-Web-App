"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import { Home, ScanLine, MapPin, Wrench, Settings, Menu, X, ShieldCheck, LogOut } from "lucide-react"
import { useState } from "react"
import { useApp } from "@/context/AppContext"
import { LanguageSwitcher } from "./LanguageSwitcher"
import { AccessTimer } from "./access/AccessTimer"
import { cn } from "@/lib/utils"

const navItems = [
  { href: "/", icon: Home, label: "Home" },
  { href: "/scanner", icon: ScanLine, label: "Scan" },
  { href: "/access", icon: ShieldCheck, label: "Access" },
  { href: "/equipment", icon: Wrench, label: "Equipment" },
  { href: "/staff", icon: Settings, label: "Staff" },
]

export function Navbar() {
  const pathname = usePathname()
  const { isStaffMode, setIsStaffMode, isAuthenticated, patientAccess, revokeAccess } = useApp()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <MapPin className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="font-bold text-xl text-foreground hidden sm:block">
                HospitalNav
              </span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-2">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "relative flex items-center gap-2 px-4 py-2 rounded-xl text-base font-medium transition-all duration-200",
                      isActive
                        ? "text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    )}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="navbar-active"
                        className="absolute inset-0 bg-primary rounded-xl"
                        transition={{ type: "spring", duration: 0.5 }}
                      />
                    )}
                    <span className="relative z-10 flex items-center gap-2">
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </span>
                  </Link>
                )
              })}
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-3">
              {/* Access Timer (when authenticated) */}
              {isAuthenticated && patientAccess && (
                <div className="hidden sm:flex items-center gap-2">
                  <AccessTimer compact />
                  <button
                    onClick={revokeAccess}
                    className="p-2 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
                    title="End Visit"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              )}
              
              <LanguageSwitcher />
              
              {/* Staff Mode Toggle */}
              <button
                onClick={() => setIsStaffMode(!isStaffMode)}
                className={cn(
                  "hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all",
                  isStaffMode
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground"
                )}
              >
                <Settings className="w-4 h-4" />
                {isStaffMode ? "Staff On" : "Staff Off"}
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-xl hover:bg-muted transition-colors"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-16 left-0 right-0 z-40 bg-card border-b border-border md:hidden"
        >
          <div className="px-4 py-4 space-y-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl text-lg font-medium transition-all",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  <item.icon className="w-6 h-6" />
                  {item.label}
                </Link>
              )
            })}
            
            <button
              onClick={() => {
                setIsStaffMode(!isStaffMode)
                setMobileMenuOpen(false)
              }}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-lg font-medium transition-all",
                isStaffMode
                  ? "bg-accent text-accent-foreground"
                  : "bg-muted text-muted-foreground"
              )}
            >
              <Settings className="w-6 h-6" />
              {isStaffMode ? "Staff Mode On" : "Staff Mode Off"}
            </button>
          </div>
        </motion.div>
      )}

      {/* Spacer for fixed navbar */}
      <div className="h-16" />
    </>
  )
}
