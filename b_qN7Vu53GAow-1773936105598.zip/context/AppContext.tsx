"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"

export type Language = "en" | "hi" | "mr"

export interface NavigationStep {
  step: number
  instruction: string
  image: string
  direction: "straight" | "left" | "right" | "up" | "down" | "destination"
}

export interface Route {
  id: string
  name: string
  department: string
  color: string
  steps: NavigationStep[]
}

export interface PatientAccess {
  patientName: string
  patientRoom: string
  visitorName: string
  relation: string
  mobile: string
  accessGrantedAt: number
  expiryTime: number
}

interface AppContextType {
  language: Language
  setLanguage: (lang: Language) => void
  currentRoute: Route | null
  setCurrentRoute: (route: Route | null) => void
  currentStep: number
  setCurrentStep: (step: number) => void
  isHighContrast: boolean
  setIsHighContrast: (value: boolean) => void
  isStaffMode: boolean
  setIsStaffMode: (value: boolean) => void
  // Patient Access System
  isAuthenticated: boolean
  patientAccess: PatientAccess | null
  accessTimeRemaining: number
  grantAccess: (access: PatientAccess) => void
  revokeAccess: () => void
  isRestrictedArea: (department: string) => boolean
}

const RESTRICTED_AREAS = ["icu", "operation theatre", "ot", "nicu", "ccu"]
const ACCESS_DURATION = 2 * 60 * 60 * 1000 // 2 hours in milliseconds

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")
  const [currentRoute, setCurrentRoute] = useState<Route | null>(null)
  const [currentStep, setCurrentStep] = useState(0)
  const [isHighContrast, setIsHighContrast] = useState(false)
  const [isStaffMode, setIsStaffMode] = useState(false)
  
  // Patient Access State
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [patientAccess, setPatientAccess] = useState<PatientAccess | null>(null)
  const [accessTimeRemaining, setAccessTimeRemaining] = useState(0)

  // Load access from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("patientAccess")
    if (stored) {
      try {
        const access = JSON.parse(stored) as PatientAccess
        const now = Date.now()
        if (now < access.expiryTime) {
          setPatientAccess(access)
          setIsAuthenticated(true)
          setAccessTimeRemaining(access.expiryTime - now)
        } else {
          localStorage.removeItem("patientAccess")
        }
      } catch {
        localStorage.removeItem("patientAccess")
      }
    }
  }, [])

  // Timer countdown
  useEffect(() => {
    if (!isAuthenticated || !patientAccess) return

    const interval = setInterval(() => {
      const now = Date.now()
      const remaining = patientAccess.expiryTime - now
      
      if (remaining <= 0) {
        revokeAccess()
      } else {
        setAccessTimeRemaining(remaining)
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [isAuthenticated, patientAccess])

  const grantAccess = (access: PatientAccess) => {
    const accessWithTimes: PatientAccess = {
      ...access,
      accessGrantedAt: Date.now(),
      expiryTime: Date.now() + ACCESS_DURATION,
    }
    setPatientAccess(accessWithTimes)
    setIsAuthenticated(true)
    setAccessTimeRemaining(ACCESS_DURATION)
    localStorage.setItem("patientAccess", JSON.stringify(accessWithTimes))
  }

  const revokeAccess = () => {
    setPatientAccess(null)
    setIsAuthenticated(false)
    setAccessTimeRemaining(0)
    localStorage.removeItem("patientAccess")
  }

  const isRestrictedArea = (department: string) => {
    return RESTRICTED_AREAS.includes(department.toLowerCase())
  }

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currentRoute,
        setCurrentRoute,
        currentStep,
        setCurrentStep,
        isHighContrast,
        setIsHighContrast,
        isStaffMode,
        setIsStaffMode,
        isAuthenticated,
        patientAccess,
        accessTimeRemaining,
        grantAccess,
        revokeAccess,
        isRestrictedArea,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within AppProvider")
  }
  return context
}
